
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.Rectangle2D;

import javax.swing.Timer;

public class GamePaddle {
	private static final int PADDLE_SIZE = 20;
	private static final int PADDLE_START_X = 10;
	private static final int PADDLE_START_Y = 200;
	private static final int STARTING_X_VELOCITY = 10;

	private int xVelocity = GamePaddle.STARTING_X_VELOCITY;
	private Rectangle2D.Double paddle;
	private boolean paddleIsPoweredUp;
	double powerUpWidthMultiplier = 1.0;
	private Timer powerDownTimer;

	// ************************************************************
	// Method section
	// ************************************************************

	public GamePaddle() {
		final int powerUpLifeTime = 3000; // 3000 = ~3 seconds

		this.paddleIsPoweredUp = false;
		this.paddle = new Rectangle2D.Double(GamePaddle.PADDLE_START_X, GamePaddle.PADDLE_START_Y,
				GamePaddle.PADDLE_SIZE, GamePaddle.PADDLE_SIZE);
		
		// Variable 'gamePaddle' is used in the anonymous ActionListener below
		GamePaddle gamePaddle = this;		
		this.powerDownTimer = new Timer(powerUpLifeTime,
				// The 2nd parameter is an anonymous inner class
				new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						// This "catches" the 1 Tick event sent by the powerDownTimer 
						gamePaddle.powerDownThePaddle();
					} // actionPerformed
				} // ActionListener
		);
		// The 'false' means that when powerDownTimer runs, it will only send one Tick to the Listener
		this.powerDownTimer.setRepeats(false);
	} // Paddle

	// ************************************************************

	public void drawOn(Graphics2D g) {
		if (this.paddleIsPoweredUp) {
			Color incomingColor = g.getColor();
			g.setColor(Color.MAGENTA);
			g.fill(this.paddle);
			g.setColor(incomingColor);
		} else {
			g.fill(this.paddle);
		} // end if
	} // drawOn

	// ************************************************************

	public void powerDownThePaddle() {
		final double widthWhenPoweredDown = 1.0;

		this.powerUpWidthMultiplier = widthWhenPoweredDown;
		this.paddleIsPoweredUp = false;
	} // powerDownThePaddle

	// ************************************************************

	public void powerUpThePaddle() {
		final double widthWhenPoweredUp = 1.5;

		this.powerUpWidthMultiplier = widthWhenPoweredUp;
		this.powerDownTimer.restart(); // the 'restart' causes the powerDownTimer to start running
		this.paddleIsPoweredUp = true;
	} // powerUpThePaddle

	// ************************************************************

	public void updatePaddleState(int currentScreenWidth) {

		// 1st Set rectangle on each update because the paddle might be powered up
		// When powered up, powerUpWidthMultiplier has a larger value
		this.paddle.setRect(this.paddle.x, this.paddle.y, (powerUpWidthMultiplier * PADDLE_SIZE), PADDLE_SIZE);

		// 2nd Move the paddle
		// if xVelocity < 0 move left
		// if xVelocity > 0 move right
		this.paddle.x += this.xVelocity;

		// 3rd Check to make sure paddle is still on the screen
		if (this.paddle.x > (currentScreenWidth - paddle.getWidth())) {
			// Don't let paddle move off right hand side of the screen
			this.paddle.x = currentScreenWidth - paddle.getWidth();
			// Make it bounce off right hand wall
			this.xVelocity *= -1;
		} else if (this.paddle.x < 0) {
			// Don't let paddle move off left hand side of screen
			this.paddle.x = 0;
			// Make it bounce off left hand wall
			this.xVelocity *= -1;
		} // end if
	} // updatePaddleState

} // Paddle
