import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JComponent;
import javax.swing.Timer;

public class MainComponent extends JComponent {

	private static final long serialVersionUID = 1L;
	private static final int TIMER_DELAY = 50;
	private GamePaddle gamePaddle;

	// ************************************************************
	// Method section
	// ************************************************************

	public MainComponent() {
		this.gamePaddle = new GamePaddle();
		
		// variable 'mainComponent' is used in the anonymous ActionListener below
		MainComponent mainComponent = this;		
		Timer gameAdvanceTimer = new Timer(MainComponent.TIMER_DELAY,
				// The 2nd parameter is an anonymous inner class
				new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						// Do this on each Tick from gameAdvanceTimer
						mainComponent.updateState();
						mainComponent.requestRepaintEvent();
					} // actionPerformed
				} // ActionListener
		);
		gameAdvanceTimer.start();
	} // MainComponent

	// ************************************************************

	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);

		Graphics2D g2 = (Graphics2D) g;
		this.gamePaddle.drawOn(g2);
	} // paintComponent

	// ************************************************************

	public void powerUpGamePaddle() {
		this.gamePaddle.powerUpThePaddle();
	} // powerUpGamePaddle

	// ************************************************************

	private void requestRepaintEvent() {
		// 'repaint' is inherited from JComponent
		// It tells Java Swing to wipe the screen clean and then send a 'paintComponent'
		// event to the program
		super.repaint();
	} // requestRepaintEvent

	// ************************************************************

	private void updateState() {
		this.gamePaddle.updatePaddleState(this.getWidth());
	} // updateState

} // MainComponent
