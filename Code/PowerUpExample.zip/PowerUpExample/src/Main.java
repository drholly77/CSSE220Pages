import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.WindowConstants;

/**
 * 
 * @author Dr. Holly
 * 
 * There are two timers in the example 
 * 1) The gameAdvanceTimer which sends regular Ticks events for regularly updating state
 * 2) A powerDownTimer which sends only 1 Tick event when it is time to power down a powered up paddle
 *
 */
public class Main {

	// ************************************************************
	// Method section
	// ************************************************************

	public static void main(String[] args) {
		new Main();
	} // main

	// ************************************************************

	private Main() {
		JFrame frame = new JFrame("Power Up Example");
		frame.setSize(500, 500);
		frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

		MainComponent component = new MainComponent();
		frame.add(component, BorderLayout.CENTER);

		JButton button = new JButton("Power Up Button");
		frame.add(button, BorderLayout.SOUTH);

		button.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				component.powerUpGamePaddle();
			} // actionPerformed
		});

		frame.setVisible(true);
	} // Main
}
