import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;

public class Raindrop {
	private double x;
	private double y;
	
	// "velocity" is how many pixels to move on one update
	private double yVelocity = 3;
	// All raindrops are the same constant size
	private static final double SIZE = 5.0;

	// ************************************************************

	public Raindrop(int range) {
		this.x = Math.random() * range;
		this.y = 0;
	} // Raindrop

	/**
	 * @param bottom The y-coordinate of the bottom of the screen.
	 * @return True if the raindrop fell off the bottom of the screen
	 */
	public boolean fall(int bottom) {
		// "velocity" is how many pixels to move on one update
		// bigger "velocity" equates to illusion of faster movement
		this.y += this.yVelocity;
		return this.y > bottom;
	} // fall

	public void drawOn(Graphics2D g) {
		Color oldColor = g.getColor();

		g.setColor(Color.BLUE);
		Ellipse2D.Double drop = new Ellipse2D.Double(this.x, this.y, SIZE, SIZE);
		g.fill(drop);
		g.setColor(oldColor);
	} // drawOn

	// Use to detect if the raindrops hit the box
	public boolean insideBox(Rectangle2D.Double b) {
		return b.intersects(x, y, SIZE, SIZE);
	} // insideBox

}
