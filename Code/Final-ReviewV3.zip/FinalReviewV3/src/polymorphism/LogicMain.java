package polymorphism;

// Use this to help you determine the answers to the questions in
// PolymorphismQuestion.pdf

public class LogicMain {

	public static void q1() {
		Logic i1 = new AndLogic();
		i1.and(true, true);
	} // q1
	
	// -----------------------------------------------------------------
	
	public static void q2() {
		FullLogic i2 = new FullLogic (new AndLogic(), new MixedLogic());
		i2.and(false, true);
	} // q2

	// -----------------------------------------------------------------
	
	public static void q3() {
		Logic i3 = new MixedLogic();
		((MixedLogic)i3).xor(true, true);
	} // q3

	// -----------------------------------------------------------------

	public static void q4() {
		// Uncomment me: 
		// OrLogic i4 = new MixedLogic();
		// i4.or(true, false);
	} // q4

	// -----------------------------------------------------------------

	public static void q5() {
		// Uncomment me: 
		// Logic i5 = new OrLogic();	
		// i5.and(true, false);
	} // q5

	// -----------------------------------------------------------------
	
	public static void q6() {
		Logic i6 = new AndLogic();
		((MixedLogic)i6).xor(true, true);
	} // q6

	// -----------------------------------------------------------------
	
	public static void main(String[] args) {
		q1();
		q2();
		q3();
		q4();
		q5();
		q6();
	} // main
}
