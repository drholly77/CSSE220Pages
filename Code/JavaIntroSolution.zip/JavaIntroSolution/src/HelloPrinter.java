/**
 * Greetings, earthlings.
 */
public class HelloPrinter {

	/**
	 * It all begins here.
	 * @param args 
	 */
	public static void main(String[] args) {
		System.out.println("Hello, Neighbor!");
	}

}
