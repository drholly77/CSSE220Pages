package quiz;

public class MainDriver {

	public static void main(String[] args) {
		Two m = new Two();
		Top q = new One();
		Top r = new Two();
		One s = new Two();

		m.alpha();
		m.gamma();
//		m.omega();
		q.alpha();
		r.beta();
//		r.epsilon();
		s.beta();
		((Two) r).epsilon();
//		((Two) q).epsilon();
//		Two w = new One();
		One x = new Two();
//		Top y = new Top();
		r.delta();

	}

}
