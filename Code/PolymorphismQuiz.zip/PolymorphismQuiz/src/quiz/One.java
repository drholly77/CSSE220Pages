package quiz;

public class One implements Top {
	
	@Override
	public void alpha() {
		System.out.println("A");
    } // alpha

	@Override
	public void beta() {
        System.out.println("B");
    } // beta

	@Override
	public void gamma() {
        System.out.println("C");
    } // gamma

	@Override
	public void delta() {
        System.out.println("D");
        this.beta();
    } // delta
} // One
