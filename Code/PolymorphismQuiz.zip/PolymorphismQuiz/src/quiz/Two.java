package quiz;

public class Two extends One implements Top {
	
	@Override
    public void beta() {
        System.out.println("E");
    } // beta

	@Override
    public void gamma() {
        super.gamma();
        System.out.println("F");
    } // gamma

    public void epsilon() {
        System.out.println("G");
    } // epsilon
} // Two
