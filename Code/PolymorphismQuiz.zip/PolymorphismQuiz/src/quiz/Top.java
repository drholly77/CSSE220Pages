package quiz;

public interface Top {
	
	void alpha(); // alpha

	void beta(); // beta

	void gamma(); // gamma

	void delta(); // delta
} // Top