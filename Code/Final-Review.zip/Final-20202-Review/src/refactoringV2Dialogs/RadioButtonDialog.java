package refactoringV2Dialogs;


import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

public class RadioButtonDialog {

	ArrayList<String> options;
	JLabel label;
	ActionListener resultListener;
	
	public RadioButtonDialog() {
		options = new ArrayList<String>();
	}
	
	public void addOption(String option) {
		options.add(option);
	}
	
	public void setActionListener(ActionListener resultListener) {
		this.resultListener = resultListener; 
	}
	
	public String getChoice() {
		return label.getText().substring(16);
	}
	
	public void showWindow() {
		JFrame frame = new JFrame("Choose Wisely!");
		
		label = new JLabel("Current choice: " + options.get(0));
		JButton ok = new JButton("Ok");
		ok.addActionListener(resultListener);		
		frame.add(label, BorderLayout.NORTH);
		frame.add(ok, BorderLayout.SOUTH);
		
		
		JPanel panel = new JPanel();
		ButtonGroup group = new ButtonGroup();
		for(String s : options) {
			JRadioButton b = new JRadioButton(s);
			b.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					label.setText("Current choice: " + s);
				}
			});
			group.add(b);
			panel.add(b);
		}
	
		
		frame.add(panel);
		
		frame.pack();
		frame.setVisible(true);
	}
	
}
