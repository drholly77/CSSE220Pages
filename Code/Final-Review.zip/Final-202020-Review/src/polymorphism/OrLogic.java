package polymorphism;

public abstract class OrLogic implements Logic {
	
	@Override
	public void or(boolean p, boolean q) {
		System.out.println("ALogic.or");
	}
}
