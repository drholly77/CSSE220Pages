package polymorphism;

public class FullLogic implements Logic {

	private Logic l1;
	private Logic l2;
	
	public FullLogic(Logic l1, Logic l2) {
		this.l1 = l1;
		this.l2 = l2;
	} // FullLogic

	@Override
	public void and(boolean p, boolean q) {
		this.l2.and(p, q);
	}

	@Override
	public void or(boolean p, boolean q) {
		this.l1.or(p, q);
	} // or
	
	public void xor(boolean p, boolean q) {
		or(p,q);
		and(p,q);
	} // xor
	
	public void not(boolean p) {
		System.out.println("FullLogic.not");
	} // not

}
