package polymorphism;

public interface Logic {
	void and(boolean p, boolean q);
	void or(boolean p, boolean q);
}
