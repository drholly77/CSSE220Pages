import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

/**
 * 
 * To see readFile try-catch in action, change the name of 
 * the file to be read so that it is different than the file written
 * by writeFile
 *
 */
public class LevelIO {

	public static void main(String[] args) {
		new LevelIO();
	} // main

	public LevelIO() {
		writeFile();
		readFile();
	} // LevelIO

	private void readFile() {
		Scanner scanner;
		
		// Recommended - the following 4 steps: 
		// (1) always declare File variable outside try-catch
		File newFileVar = null;

		try {
			// (2) call 'new File("filename.ext")' inside try block
			newFileVar = new File("levelV1.txt");
			
			// (3) pass File variable to Scanner constructor
			scanner = new Scanner(newFileVar);
		} catch (FileNotFoundException e) {
			// If we get here, then an exception occured
			
			// (4) call File's method getAbsolutePath() to output
			//     information about where File was looking for the actual file
			System.out.println("absolute path: " + newFileVar.getAbsolutePath());
			System.out.println("levelV1.txt not found");
			return;
		} // end try-catch
		
		// Once we get here, we know the File and Scanner are 
		// both set up correctly
		String title = scanner.nextLine();
		System.out.println("Title: " + title);
		while (scanner.hasNextLine()) {
			String line = scanner.nextLine();
			System.out.println(line.charAt(0));
			System.out.println(line);
		} // end while
		scanner.close();
	} // readFile

	private void writeFile() {
		PrintWriter pw = null;
	
		try {
			pw = new PrintWriter("levelV1.txt");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			return;
		} // end try-catch
		
		
		// Once we get here, we know that PrintWriter is 
		// set up correctly
		pw.println("Sample level");
		pw.println("/-------------\\");
		pw.println("|.............|");
		pw.close();
	} // writeFile
} // LevelIO


