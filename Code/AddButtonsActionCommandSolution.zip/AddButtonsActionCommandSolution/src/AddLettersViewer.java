import java.awt.BorderLayout;
import java.awt.Dimension;
import java.util.ArrayList;
import java.util.Arrays;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class AddLettersViewer {

	public static void main(String[] args) {
		new AddLettersViewer();
	} // main

	public AddLettersViewer() {
		JFrame frame = new JFrame("Updated Solution - Using Action Commands");
		frame.setMinimumSize(new Dimension(400,50));
		JPanel buttonPanel = new JPanel();
		
		JLabel userFeedback = new JLabel("> ");
		ArrayList<String> lettersToAdd = new ArrayList<String>(Arrays.asList("A", "B", "C"));
		AddLettersListener buttonListener = new AddLettersListener(userFeedback, lettersToAdd);

		// -------------------------------------------------------------------
		// Create all 3 buttons
		// Note: 1 Listener object handles all three Buttons
		// Each button's actionCommand gets set here to a unique id: 0, 1 or 2
		// -------------------------------------------------------------------
		JButton aButton = new JButton("Add A");
		aButton.setActionCommand("0");
		aButton.addActionListener(buttonListener);
		buttonPanel.add(aButton);
		
		JButton bButton = new JButton("Add B");
		bButton.setActionCommand("1");
		bButton.addActionListener(buttonListener);
		buttonPanel.add(bButton);
		
		JButton cButton = new JButton("Add C");
		cButton.setActionCommand("2");
		cButton.addActionListener(buttonListener);
		buttonPanel.add(cButton);
		// -------------------------------------------------------------------
		
		// Fill up the frame
		frame.add(userFeedback, BorderLayout.CENTER);
		frame.add(buttonPanel, BorderLayout.SOUTH);

		// -------------------------------------------------------------------

		frame.pack();		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	} // AddLettersViewer
}
