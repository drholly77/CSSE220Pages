import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.JLabel;

public class AddLettersListener implements ActionListener {

	// -------------------------------------------------------------------
	// These 2 objects were created in the main program
	// We just keep a reference to them so that we can access them
	// when actionPerformed gets invoked
	// -------------------------------------------------------------------
	private JLabel userFeedback;
	private List<String> lettersToAdd;

	public AddLettersListener(JLabel letterDisplay, List<String> lettersToAdd) {
		this.userFeedback = letterDisplay;
		this.lettersToAdd = lettersToAdd;
	} // AddLettersListener

	@Override
	public void actionPerformed(ActionEvent e) {
		// -------------------------------------------------------------------
		// Each button's actionCommand was set when the buttons were created
		// So buttonId should be either: 0, 1, or 2
		// -------------------------------------------------------------------
		int buttonId = Integer.parseInt(e.getActionCommand());
		String newLabel = userFeedback.getText() + lettersToAdd.get(buttonId);
		userFeedback.setText(newLabel);
	} // actionPerformed

}
