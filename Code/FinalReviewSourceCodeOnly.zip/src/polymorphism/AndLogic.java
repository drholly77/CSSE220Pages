package polymorphism;

public class AndLogic extends OrLogic {

	@Override
	public void and(boolean p, boolean q) {
		// TODO Auto-generated method stub

	}

}
