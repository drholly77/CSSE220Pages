package polymorphism;

public class MixedLogic implements Logic {

	@Override
	public void and(boolean p, boolean q) {
		System.out.println("CrazyLogic.and");
	}

	@Override
	public void or(boolean p, boolean q) {
		System.out.println("CrazyLogic.or");
	}
	
	public void xor(boolean p, boolean q) {
		or(p,q);
		and(p,q);
	}

}
