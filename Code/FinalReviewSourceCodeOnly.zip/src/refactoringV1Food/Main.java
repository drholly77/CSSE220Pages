package refactoringV1Food;


import java.util.ArrayList;

public class Main {

	private ArrayList<Object> orders;
	
	public Main() {
		orders = new ArrayList<>();
		setupOrders();
	}

	public void setupOrders() {
		// you should not need to change this function
		orders.add(new Pizza("pepperoni"));
		orders.add(new Cookies(100));
		orders.add(new Pizza("olive"));
		orders.add(new Pizza("mushroom"));
		orders.add(new Souffle());
	}
	
	public void makeAllOrders() {
		while(!orders.isEmpty()) {
			Object order = orders.remove(0);
			if(order instanceof Pizza) {
				Pizza pizzaOrder = (Pizza) order;
				pizzaOrder.prepare();
				pizzaOrder.bake();
			}
			if(order instanceof Cookies) {
				Cookies cookieOrder = (Cookies) order;
				cookieOrder.prepare();
				cookieOrder.bake();
			}
			if(order instanceof Souffle) {
				Souffle souffleOrder = (Souffle) order;
				souffleOrder.prepare();
				souffleOrder.bake();
			}
		}
	}
	
	public static void main(String[] args) {
		Main main = new Main();
		main.makeAllOrders();
	}
}
