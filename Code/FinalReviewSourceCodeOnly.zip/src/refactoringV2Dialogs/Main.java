package refactoringV2Dialogs;


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

public class Main {

	public static void main(String[] args) {
		
		String[] options = {"Maurizio's Pizza", "Wise Pies", "Pizza City!", "Azzip Pizza"};
		
		
		String sResult = JOptionPane.showInputDialog("What type of dialog would you like (enter a number 1-3)");
		
		//let's not worry about error handling and assume we alway get a valid number
		int result = Integer.parseInt(sResult);
	
		if(result == 1) {
			ButtonDialog dialog = new ButtonDialog();
			for(String option : options) {
				dialog.addOption(option);
			} // end for
			dialog.setActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					System.out.println("The user chose " + dialog.getChoice());
					System.exit(0);
					
				}
			});
			dialog.showWindow();			
		} // end if
		
		if(result == 2) {
			ListDialog dialog = new ListDialog();
			for(String option : options) {
				dialog.addOption(option);
			} // end for
			dialog.setActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					System.out.println("The user chose " + dialog.getChoice());
					System.exit(0);
					
				}
			});
			dialog.showWindow();			
		} // end if
		
		if(result == 3) {
			RadioButtonDialog dialog = new RadioButtonDialog();
			for(String option : options) {
				dialog.addOption(option);
			} // end for
			dialog.setActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					System.out.println("The user chose " + dialog.getChoice());
					System.exit(0);
					
				}
			});
			dialog.showWindow();			
		} // end if
		
	}
	
}
